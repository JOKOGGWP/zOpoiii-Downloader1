package com.zopoiii.downloader.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Speedometer(
    currentSpeedBytesPerSec: Long,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    label: String = "DOWNLOAD SPEED"
) {
    // Determine appropriate units and scale
    val speedBytes = currentSpeedBytesPerSec.coerceAtLeast(0L).toDouble()
    val speedKb = speedBytes / 1024.0
    val speedMb = speedKb / 1024.0
    val speedGb = speedMb / 1024.0

    val (displayValue, unit, maxScale) = when {
        speedGb >= 1.0 -> Triple(
            String.format(java.util.Locale.US, "%.2f", speedGb),
            "GB/s",
            calculateMaxScale(speedGb)
        )
        speedMb >= 1.0 -> Triple(
            String.format(java.util.Locale.US, "%.1f", speedMb),
            "MB/s",
            calculateMaxScale(speedMb)
        )
        speedKb >= 1.0 -> Triple(
            String.format(java.util.Locale.US, "%.1f", speedKb),
            "KB/s",
            calculateMaxScale(speedKb)
        )
        else -> Triple(
            "${currentSpeedBytesPerSec.coerceAtLeast(0L)}",
            "B/s",
            1000.0
        )
    }

    val numericValue = displayValue.toDoubleOrNull() ?: 0.0
    val fraction = (numericValue / maxScale).toFloat().coerceIn(0f, 1f)

    val animatedFraction by animateFloatAsState(
        targetValue = fraction,
        animationSpec = tween(durationMillis = 350),
        label = "speedometer_needle"
    )

    SpeedometerGauge(
        fraction = animatedFraction,
        displayValue = displayValue,
        unit = unit,
        maxLabel = "${maxScale.toInt()}",
        label = label,
        modifier = modifier,
        size = size
    )
}

@Composable
fun MbpsSpeedometer(
    currentSpeedMbps: Double,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    label: String = "DOWNLOAD"
) {
    val speed = if (currentSpeedMbps.isNaN() || currentSpeedMbps.isInfinite()) 0.0 else currentSpeedMbps.coerceAtLeast(0.0)
    val maxScale = calculateMaxScale(speed)
    val fraction = (speed / maxScale).toFloat().coerceIn(0f, 1f)

    val animatedFraction by animateFloatAsState(
        targetValue = fraction,
        animationSpec = tween(durationMillis = 300),
        label = "mbps_gauge"
    )

    SpeedometerGauge(
        fraction = animatedFraction,
        displayValue = String.format(java.util.Locale.US, "%.1f", speed),
        unit = "Mbps",
        maxLabel = "${maxScale.toInt()}",
        label = label,
        modifier = modifier,
        size = size
    )
}

private fun calculateMaxScale(currentVal: Double): Double {
    return when {
        currentVal <= 10.0 -> 10.0
        currentVal <= 25.0 -> 25.0
        currentVal <= 50.0 -> 50.0
        currentVal <= 100.0 -> 100.0
        currentVal <= 250.0 -> 250.0
        currentVal <= 500.0 -> 500.0
        currentVal <= 1000.0 -> 1000.0
        else -> (currentVal * 1.3).coerceAtLeast(1500.0)
    }
}

@Composable
private fun SpeedometerGauge(
    fraction: Float,
    displayValue: String,
    unit: String,
    maxLabel: String,
    label: String,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val tertiaryColor = MaterialTheme.colorScheme.tertiary
    val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val strokeWidth = 14.dp.toPx()
            val radius = (this.size.minDimension - strokeWidth) / 2
            val center = Offset(this.size.width / 2, this.size.height / 2)

            val startAngle = 140f
            val totalSweep = 260f

            // 1. Background Arc Track
            drawArc(
                color = trackColor,
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // 2. Active Progress Arc with Gradient
            val activeSweep = totalSweep * fraction
            if (activeSweep > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        0.3f to primaryColor,
                        0.7f to tertiaryColor,
                        center = center
                    ),
                    startAngle = startAngle,
                    sweepAngle = activeSweep,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            // 3. Tick Marks (5 ticks)
            val numTicks = 5
            for (i in 0 until numTicks) {
                val tickFraction = i.toFloat() / (numTicks - 1)
                val tickAngleDeg = startAngle + totalSweep * tickFraction
                val tickAngleRad = tickAngleDeg * (PI / 180.0)

                val tickInnerRadius = radius - 16.dp.toPx()
                val tickOuterRadius = radius - 8.dp.toPx()

                val innerX = center.x + tickInnerRadius * cos(tickAngleRad).toFloat()
                val innerY = center.y + tickInnerRadius * sin(tickAngleRad).toFloat()
                val outerX = center.x + tickOuterRadius * cos(tickAngleRad).toFloat()
                val outerY = center.y + tickOuterRadius * sin(tickAngleRad).toFloat()

                drawLine(
                    color = outlineColor,
                    start = Offset(innerX, innerY),
                    end = Offset(outerX, outerY),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 4. Needle Indicator
            val needleAngleDeg = startAngle + totalSweep * fraction
            val needleAngleRad = needleAngleDeg * (PI / 180.0)
            val needleRadius = radius - 20.dp.toPx()

            val needleTipX = center.x + needleRadius * cos(needleAngleRad).toFloat()
            val needleTipY = center.y + needleRadius * sin(needleAngleRad).toFloat()

            // Needle line
            drawLine(
                color = primaryColor,
                start = center,
                end = Offset(needleTipX, needleTipY),
                strokeWidth = 3.5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Needle Center Hub
            drawCircle(
                color = primaryColor,
                radius = 7.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = center
            )
        }

        // Center Digital Display
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = displayValue,
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 32.sp),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = unit,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
