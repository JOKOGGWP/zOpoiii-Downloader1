package com.zopoiii.downloader.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.zopoiii.downloader.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val url: String,
    val filename: String,
    val destinationPath: String,
    val totalBytes: Long,
    val downloadedBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val etag: String? = null,
    val lastModified: String? = null,
    val acceptRanges: Boolean = true,
    val connectionCount: Int = 1,
    val segmentInformation: String? = null,
    val errorMessage: String? = null,
    val mimeType: String? = null,
    val checksum: String? = null
) {
    val progressPercent: Float
        get() = if (totalBytes > 0L) {
            ((downloadedBytes.toDouble() / totalBytes.toDouble()) * 100).toFloat().coerceIn(0f, 100f)
        } else 0f

    val remainingBytes: Long
        get() = if (totalBytes > 0L) (totalBytes - downloadedBytes).coerceAtLeast(0L) else -1L

    val isCompleted: Boolean
        get() = status == DownloadStatus.COMPLETED

    val isDownloading: Boolean
        get() = status == DownloadStatus.DOWNLOADING
}
