package com.zopoiii.downloader.engine

import com.zopoiii.downloader.model.FileMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object UrlMetadataResolver {

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val CONTENT_RANGE_PATTERN = Pattern.compile(
        """bytes\s+\d+-\d+/(\d+|\*)""",
        Pattern.CASE_INSENSITIVE
    )

    suspend fun resolve(rawUrl: String): Result<FileMetadata> = withContext(Dispatchers.IO) {
        try {
            var url = rawUrl.trim()
            if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                url = "https://$url"
            }

            // Step 1: Attempt HEAD request first
            val headRequest = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", "zOpoiii-Downloader/1.0 (Android)")
                .build()

            var response = try {
                client.newCall(headRequest).execute()
            } catch (_: Exception) {
                null
            }

            // Check if HEAD succeeded and yielded meaningful headers
            val isHeadAcceptable = response != null && response.isSuccessful &&
                    (response.header("Content-Length") != null || response.header("Accept-Ranges") != null)

            if (!isHeadAcceptable) {
                response?.close()
                // Step 2: Fallback to safe GET with Range: bytes=0-0 (downloads only 1 byte!)
                val rangeGetRequest = Request.Builder()
                    .url(url)
                    .get()
                    .header("User-Agent", "zOpoiii-Downloader/1.0 (Android)")
                    .header("Range", "bytes=0-0")
                    .build()

                response = client.newCall(rangeGetRequest).execute()
            }

            response.use { resp ->
                val finalUrl = resp.request.url.toString()
                val statusCode = resp.code

                if (!resp.isSuccessful && statusCode != 206) {
                    return@withContext Result.failure(
                        IOException(
                            when (statusCode) {
                                404 -> "HTTP 404: File not found on server"
                                403 -> "HTTP 403: Access forbidden"
                                401 -> "HTTP 401: Unauthorized"
                                500, 502, 503 -> "Server error ($statusCode)"
                                else -> "Server returned HTTP $statusCode"
                            }
                        )
                    )
                }

                val contentDisposition = resp.header("Content-Disposition")
                val contentType = resp.header("Content-Type")
                val etag = resp.header("ETag")
                val lastModified = resp.header("Last-Modified")
                val acceptRangesHeader = resp.header("Accept-Ranges")
                val contentRangeHeader = resp.header("Content-Range")

                // Range support determination:
                // 1. Status 206 Partial Content confirms range support directly
                // 2. Accept-Ranges header containing 'bytes'
                // 3. Content-Range header present in response
                val isRangeSupported = statusCode == 206 ||
                        acceptRangesHeader?.contains("bytes", ignoreCase = true) == true ||
                        !contentRangeHeader.isNullOrBlank()

                // Determine total size
                var totalBytes: Long = -1L
                if (!contentRangeHeader.isNullOrBlank()) {
                    val matcher = CONTENT_RANGE_PATTERN.matcher(contentRangeHeader)
                    if (matcher.find()) {
                        val totalStr = matcher.group(1)
                        if (totalStr != null && totalStr != "*") {
                            totalBytes = totalStr.toLongOrNull() ?: -1L
                        }
                    }
                }

                if (totalBytes <= 0L) {
                    val contentLengthHeader = resp.header("Content-Length")
                    totalBytes = contentLengthHeader?.toLongOrNull() ?: -1L
                }

                val detectedFilename = FilenameUtils.extractFilename(
                    contentDisposition = contentDisposition,
                    url = finalUrl
                )

                Result.success(
                    FileMetadata(
                        url = rawUrl,
                        resolvedUrl = finalUrl,
                        filename = detectedFilename,
                        totalBytes = totalBytes,
                        isRangeSupported = isRangeSupported,
                        contentType = contentType,
                        etag = etag,
                        lastModified = lastModified,
                        contentDisposition = contentDisposition
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
