package com.zopoiii.downloader.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zopoiii.downloader.model.ConnectionMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "zopoiii_settings")

data class AppSettings(
    val connectionMode: ConnectionMode = ConnectionMode.AUTO,
    val maxConnections: Int = 16,
    val retryAuto: Boolean = true,
    val autoResume: Boolean = true,
    val backgroundDownload: Boolean = true,
    val speedLimitBytesPerSec: Long = 0L,
    val allowWifi: Boolean = true,
    val allowMobileData: Boolean = true,
    val downloadOnlyWifi: Boolean = false,
    val pauseWhenMobile: Boolean = false,
    val continueOnLowBattery: Boolean = true,
    val lowBatteryThreshold: Int = 15,
    val maxSimultaneousDownloads: Int = 2
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val CONNECTION_MODE = intPreferencesKey("connection_mode")
        val MAX_CONNECTIONS = intPreferencesKey("max_connections")
        val RETRY_AUTO = booleanPreferencesKey("retry_auto")
        val AUTO_RESUME = booleanPreferencesKey("auto_resume")
        val BACKGROUND_DOWNLOAD = booleanPreferencesKey("background_download")
        val SPEED_LIMIT = longPreferencesKey("speed_limit_bytes")
        val ALLOW_WIFI = booleanPreferencesKey("allow_wifi")
        val ALLOW_MOBILE = booleanPreferencesKey("allow_mobile")
        val DOWNLOAD_ONLY_WIFI = booleanPreferencesKey("download_only_wifi")
        val PAUSE_WHEN_MOBILE = booleanPreferencesKey("pause_when_mobile")
        val CONTINUE_LOW_BATTERY = booleanPreferencesKey("continue_low_battery")
        val LOW_BATTERY_THRESHOLD = intPreferencesKey("low_battery_threshold")
        val MAX_CONCURRENT = intPreferencesKey("max_simultaneous_downloads")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            connectionMode = ConnectionMode.fromInt(prefs[Keys.CONNECTION_MODE] ?: 0),
            maxConnections = prefs[Keys.MAX_CONNECTIONS] ?: 16,
            retryAuto = prefs[Keys.RETRY_AUTO] ?: true,
            autoResume = prefs[Keys.AUTO_RESUME] ?: true,
            backgroundDownload = prefs[Keys.BACKGROUND_DOWNLOAD] ?: true,
            speedLimitBytesPerSec = prefs[Keys.SPEED_LIMIT] ?: 0L,
            allowWifi = prefs[Keys.ALLOW_WIFI] ?: true,
            allowMobileData = prefs[Keys.ALLOW_MOBILE] ?: true,
            downloadOnlyWifi = prefs[Keys.DOWNLOAD_ONLY_WIFI] ?: false,
            pauseWhenMobile = prefs[Keys.PAUSE_WHEN_MOBILE] ?: false,
            continueOnLowBattery = prefs[Keys.CONTINUE_LOW_BATTERY] ?: true,
            lowBatteryThreshold = prefs[Keys.LOW_BATTERY_THRESHOLD] ?: 15,
            maxSimultaneousDownloads = prefs[Keys.MAX_CONCURRENT] ?: 2
        )
    }

    suspend fun updateConnectionMode(mode: ConnectionMode) {
        context.dataStore.edit { it[Keys.CONNECTION_MODE] = mode.connectionCount }
    }

    suspend fun updateMaxConnections(count: Int) {
        context.dataStore.edit { it[Keys.MAX_CONNECTIONS] = count }
    }

    suspend fun updateSpeedLimit(bytesPerSec: Long) {
        context.dataStore.edit { it[Keys.SPEED_LIMIT] = bytesPerSec }
    }

    suspend fun updateRetryAuto(enabled: Boolean) {
        context.dataStore.edit { it[Keys.RETRY_AUTO] = enabled }
    }

    suspend fun updateAutoResume(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RESUME] = enabled }
    }

    suspend fun updateBackgroundDownload(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BACKGROUND_DOWNLOAD] = enabled }
    }

    suspend fun updateDownloadOnlyWifi(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DOWNLOAD_ONLY_WIFI] = enabled }
    }

    suspend fun updatePauseWhenMobile(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PAUSE_WHEN_MOBILE] = enabled }
    }

    suspend fun updateContinueLowBattery(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CONTINUE_LOW_BATTERY] = enabled }
    }

    suspend fun updateLowBatteryThreshold(threshold: Int) {
        context.dataStore.edit { it[Keys.LOW_BATTERY_THRESHOLD] = threshold }
    }

    suspend fun updateMaxSimultaneousDownloads(max: Int) {
        context.dataStore.edit { it[Keys.MAX_CONCURRENT] = max }
    }
}
