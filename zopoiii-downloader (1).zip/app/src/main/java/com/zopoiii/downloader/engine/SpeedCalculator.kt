package com.zopoiii.downloader.engine

import com.zopoiii.downloader.model.SpeedInfo
import java.util.concurrent.atomic.AtomicLong

class SpeedCalculator(
    private val totalBytes: Long,
    private val initialDownloadedBytes: Long = 0L
) {
    private val startTimeNanos = System.nanoTime()
    private var lastSampleTimeNanos = startTimeNanos
    private var lastSampleBytes = initialDownloadedBytes

    private val currentTotalBytes = AtomicLong(initialDownloadedBytes)

    // Moving average of recent instantaneous speeds (samples in bytes/sec)
    private val recentSpeedSamples = ArrayDeque<Long>(5)

    fun addBytes(bytes: Long) {
        currentTotalBytes.addAndGet(bytes)
    }

    fun setTotalDownloaded(bytes: Long) {
        currentTotalBytes.set(bytes)
    }

    fun sample(): SpeedInfo {
        val now = System.nanoTime()
        val currentBytes = currentTotalBytes.get()

        val timeDeltaSec = (now - lastSampleTimeNanos).toDouble() / 1_000_000_000.0
        val bytesDelta = (currentBytes - lastSampleBytes).coerceAtLeast(0L)

        var instantSpeed = 0L
        if (timeDeltaSec >= 0.25) { // Minimum 250ms interval for sample
            instantSpeed = (bytesDelta / timeDeltaSec).toLong()
            lastSampleTimeNanos = now
            lastSampleBytes = currentBytes

            synchronized(recentSpeedSamples) {
                if (recentSpeedSamples.size >= 5) {
                    recentSpeedSamples.removeFirst()
                }
                recentSpeedSamples.addLast(instantSpeed)
            }
        }

        val smoothedCurrentSpeed = synchronized(recentSpeedSamples) {
            if (recentSpeedSamples.isNotEmpty()) {
                recentSpeedSamples.average().toLong()
            } else {
                instantSpeed
            }
        }

        // Average speed over the entire active session
        val totalElapsedSec = (now - startTimeNanos).toDouble() / 1_000_000_000.0
        val totalSessionBytes = (currentBytes - initialDownloadedBytes).coerceAtLeast(0L)
        val averageSpeed = if (totalElapsedSec > 0.5) {
            (totalSessionBytes / totalElapsedSec).toLong()
        } else {
            smoothedCurrentSpeed
        }

        // ETA calculation
        val remainingBytes = if (totalBytes > 0) (totalBytes - currentBytes).coerceAtLeast(0L) else -1L
        val effectiveSpeedForEta = if (smoothedCurrentSpeed > 0) smoothedCurrentSpeed else averageSpeed
        val etaSeconds = if (remainingBytes > 0 && effectiveSpeedForEta > 0) {
            remainingBytes / effectiveSpeedForEta
        } else if (remainingBytes == 0L) {
            0L
        } else {
            -1L
        }

        return SpeedInfo(
            currentBytesPerSec = smoothedCurrentSpeed,
            averageBytesPerSec = averageSpeed,
            etaSeconds = etaSeconds
        )
    }
}
