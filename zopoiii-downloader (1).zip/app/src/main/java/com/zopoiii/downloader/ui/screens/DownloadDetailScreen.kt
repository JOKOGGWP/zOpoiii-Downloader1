package com.zopoiii.downloader.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.ui.MainViewModel
import com.zopoiii.downloader.ui.components.SegmentVisualizer
import com.zopoiii.downloader.ui.components.Speedometer
import com.zopoiii.downloader.ui.theme.StatusActive
import com.zopoiii.downloader.ui.theme.StatusError
import com.zopoiii.downloader.ui.theme.StatusSuccess
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadDetailScreen(
    downloadId: Long,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val downloadState by viewModel.getDownloadById(downloadId).collectAsState(initial = null)
    val segments by viewModel.getSegmentsForDownload(downloadId).collectAsState(initial = emptyList())
    val speeds by viewModel.speeds.collectAsState()
    val speed = speeds[downloadId] ?: SpeedInfo()

    var checksumInput by remember { mutableStateOf("") }
    var selectedAlgorithm by remember { mutableStateOf("SHA-256") }
    var isVerifyingChecksum by remember { mutableStateOf(false) }
    var checksumResult by remember { mutableStateOf<Boolean?>(null) }
    var checksumErrorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Download Detail", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (downloadState == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val download = downloadState!!

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Speedometer section (active when downloading or shows 0 when idle)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Speedometer(
                            currentSpeedBytesPerSec = if (download.status == DownloadStatus.DOWNLOADING) speed.currentBytesPerSec else 0L,
                            size = 210.dp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Overall Progress
                        LinearProgressIndicator(
                            progress = {
                                if (download.status == DownloadStatus.COMPLETED) 1f
                                else (download.progressPercent / 100f).coerceIn(0f, 1f)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = when (download.status) {
                                DownloadStatus.DOWNLOADING -> StatusActive
                                DownloadStatus.COMPLETED -> StatusSuccess
                                DownloadStatus.FAILED -> StatusError
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${SpeedInfo.formatBytes(download.downloadedBytes)} of ${SpeedInfo.formatBytes(download.totalBytes)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = String.format(java.util.Locale.US, "%.1f%%", download.progressPercent),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        if (download.status == DownloadStatus.DOWNLOADING) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Avg Speed: ${speed.formattedAverageSpeed}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "ETA: ${speed.formattedEta}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Primary Control Buttons Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    when (download.status) {
                        DownloadStatus.DOWNLOADING -> {
                            Button(
                                onClick = { viewModel.pauseDownload(download.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("PAUSE")
                            }
                            OutlinedButton(
                                onClick = { viewModel.cancelDownload(download.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Cancel, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CANCEL")
                            }
                        }
                        DownloadStatus.PAUSED, DownloadStatus.QUEUED -> {
                            Button(
                                onClick = { viewModel.resumeDownload(download.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("RESUME")
                            }
                            OutlinedButton(
                                onClick = { viewModel.cancelDownload(download.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Cancel, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CANCEL")
                            }
                        }
                        DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                            Button(
                                onClick = { viewModel.retryDownload(download.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("RETRY")
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.deleteDownload(download.id, false)
                                    onNavigateBack()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("DELETE")
                            }
                        }
                        DownloadStatus.COMPLETED -> {
                            Button(
                                onClick = { openDownloadedFile(context, download) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("OPEN FILE")
                            }
                            OutlinedButton(
                                onClick = { shareDownloadedFile(context, download) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SHARE")
                            }
                        }
                    }
                }
            }

            // Multi-Connection / Segments Breakdown
            if (segments.isNotEmpty()) {
                item {
                    SegmentVisualizer(segments = segments)
                }
            }

            // File Information Details
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "File Information",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        DetailRow(label = "Filename", value = download.filename)
                        DetailRow(label = "Status", value = download.status.name)
                        DetailRow(label = "Total Size", value = SpeedInfo.formatBytes(download.totalBytes))
                        DetailRow(label = "Downloaded", value = SpeedInfo.formatBytes(download.downloadedBytes))
                        DetailRow(label = "Connections", value = "${download.connectionCount} connections")
                        DetailRow(label = "Multi-connection (Range)", value = if (download.acceptRanges) "Supported" else "Single connection only")
                        DetailRow(label = "Destination", value = download.destinationPath, isPath = true)
                        DetailRow(label = "URL", value = download.url, isPath = true)

                        if (!download.errorMessage.isNullOrBlank()) {
                            DetailRow(label = "Error", value = download.errorMessage, isError = true)
                        }
                    }
                }
            }

            // Checksum / File Integrity Verification
            if (download.status == DownloadStatus.COMPLETED) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "File Integrity (Checksum)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Algorithm selector (MD5, SHA-1, SHA-256)
                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                listOf("MD5", "SHA-1", "SHA-256").forEachIndexed { index, algo ->
                                    SegmentedButton(
                                        selected = selectedAlgorithm == algo,
                                        onClick = { selectedAlgorithm = algo },
                                        shape = SegmentedButtonDefaults.itemShape(index = index, count = 3)
                                    ) {
                                        Text(algo)
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = checksumInput,
                                onValueChange = {
                                    checksumInput = it
                                    checksumResult = null
                                    checksumErrorMessage = null
                                },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Paste expected $selectedAlgorithm hash...") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Button(
                                onClick = {
                                    if (checksumInput.isBlank()) return@Button
                                    isVerifyingChecksum = true
                                    checksumResult = null
                                    checksumErrorMessage = null
                                    coroutineScope.launch {
                                        val res = viewModel.verifyChecksum(
                                            downloadId = download.id,
                                            expectedHash = checksumInput,
                                            algorithm = selectedAlgorithm
                                        )
                                        isVerifyingChecksum = false
                                        res.fold(
                                            onSuccess = { matches -> checksumResult = matches },
                                            onFailure = { err -> checksumErrorMessage = err.message }
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = checksumInput.isNotBlank() && !isVerifyingChecksum,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isVerifyingChecksum) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Computing $selectedAlgorithm...")
                                } else {
                                    Text("Verify Checksum")
                                }
                            }

                            if (checksumResult != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (checksumResult == true) StatusSuccess.copy(alpha = 0.15f)
                                            else StatusError.copy(alpha = 0.15f)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Icon(
                                        imageVector = if (checksumResult == true) Icons.Default.CheckCircle else Icons.Default.Error,
                                        contentDescription = null,
                                        tint = if (checksumResult == true) StatusSuccess else StatusError
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (checksumResult == true) "Integrity verified! Hash matches perfectly."
                                        else "Hash mismatch! File may be incomplete or corrupted.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (checksumResult == true) StatusSuccess else StatusError
                                    )
                                }
                            } else if (checksumErrorMessage != null) {
                                Text(
                                    text = checksumErrorMessage!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusError
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    isPath: Boolean = false,
    isError: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = if (isError) StatusError else MaterialTheme.colorScheme.onSurface,
            maxLines = if (isPath) 2 else 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun openDownloadedFile(context: Context, download: DownloadEntity) {
    val file = File(download.destinationPath)
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
        return
    }

    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, download.mimeType ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot open file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun shareDownloadedFile(context: Context, download: DownloadEntity) {
    val file = File(download.destinationPath)
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
        return
    }

    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = download.mimeType ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot share file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
