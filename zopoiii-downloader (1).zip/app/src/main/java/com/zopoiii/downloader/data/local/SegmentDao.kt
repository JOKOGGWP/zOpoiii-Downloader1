package com.zopoiii.downloader.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.zopoiii.downloader.model.SegmentStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface SegmentDao {
    @Query("SELECT * FROM segments WHERE downloadId = :downloadId ORDER BY segmentIndex ASC")
    fun getSegmentsForDownloadFlow(downloadId: Long): Flow<List<SegmentEntity>>

    @Query("SELECT * FROM segments WHERE downloadId = :downloadId ORDER BY segmentIndex ASC")
    suspend fun getSegmentsForDownload(downloadId: Long): List<SegmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSegments(segments: List<SegmentEntity>)

    @Update
    suspend fun updateSegment(segment: SegmentEntity)

    @Query("UPDATE segments SET downloadedBytes = :downloadedBytes, status = :status WHERE segmentId = :segmentId")
    suspend fun updateSegmentProgress(segmentId: Long, downloadedBytes: Long, status: SegmentStatus)

    @Query("DELETE FROM segments WHERE downloadId = :downloadId")
    suspend fun deleteSegmentsForDownload(downloadId: Long)
}
