package com.zopoiii.downloader.engine

import com.zopoiii.downloader.model.ConnectionMode

object SmartConnectionManager {

    /**
     * Determines optimal connection count based on range support, file size, and configured mode.
     */
    fun calculateInitialConnections(
        isRangeSupported: Boolean,
        totalBytes: Long,
        preferredMode: ConnectionMode,
        maxConfiguredConnections: Int = 16
    ): Int {
        if (!isRangeSupported || totalBytes <= 0L) {
            return 1
        }

        // If user set explicit fixed connection count (1, 2, 4, 8, 16)
        if (preferredMode != ConnectionMode.AUTO) {
            val desired = preferredMode.connectionCount.coerceAtMost(maxConfiguredConnections)
            // Ensure segment size isn't smaller than 1MB per connection
            val maxAllowedByMinChunk = (totalBytes / (1024 * 1024)).toInt().coerceAtLeast(1)
            return desired.coerceAtMost(maxAllowedByMinChunk)
        }

        // AUTO Mode: Scale based on file size
        val autoCount = when {
            totalBytes < 10L * 1024L * 1024L -> 1 // < 10 MB
            totalBytes < 100L * 1024L * 1024L -> 2 // 10 MB - 100 MB
            totalBytes < 1024L * 1024L * 1024L -> 4 // 100 MB - 1 GB
            totalBytes < 10L * 1024L * 1024L * 1024L -> 8 // 1 GB - 10 GB
            else -> 16 // > 10 GB
        }

        return autoCount.coerceAtMost(maxConfiguredConnections)
    }

    /**
     * Divides totalBytes into [connectionCount] continuous segments.
     * Returns List of Pair<startByte, endByte>.
     */
    fun calculateSegments(totalBytes: Long, connectionCount: Int): List<Pair<Long, Long>> {
        if (totalBytes <= 0L || connectionCount <= 1) {
            return listOf(0L to (if (totalBytes > 0) totalBytes - 1L else Long.MAX_VALUE))
        }

        val count = connectionCount.coerceAtLeast(1)
        val segmentSize = totalBytes / count
        val segments = mutableListOf<Pair<Long, Long>>()

        for (i in 0 until count) {
            val start = i * segmentSize
            val end = if (i == count - 1) totalBytes - 1L else ((i + 1) * segmentSize - 1L)
            segments.add(start to end)
        }

        return segments
    }
}
