package com.zopoiii.downloader.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.zopoiii.downloader.MainActivity
import com.zopoiii.downloader.R
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.engine.DownloadManager
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.SpeedInfo

class DownloadForegroundService : Service() {

    private val TAG = "DownloadFGService"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Immediately start foreground on service creation to satisfy Android requirements
        promoteToForeground(buildInitialNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Guarantee startForeground is called on every entry point before any processing
        promoteToForeground(buildInitialNotification())

        when (intent?.action) {
            ACTION_PAUSE -> {
                val id = intent.getLongExtra(EXTRA_DOWNLOAD_ID, -1L)
                if (id != -1L) {
                    DownloadManager.getInstance(applicationContext).pauseDownload(id)
                }
            }
            ACTION_RESUME -> {
                val id = intent.getLongExtra(EXTRA_DOWNLOAD_ID, -1L)
                if (id != -1L) {
                    DownloadManager.getInstance(applicationContext).startOrResume(id)
                }
            }
            ACTION_CANCEL -> {
                val id = intent.getLongExtra(EXTRA_DOWNLOAD_ID, -1L)
                if (id != -1L) {
                    DownloadManager.getInstance(applicationContext).cancelDownload(id)
                }
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun promoteToForeground(notification: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to startForeground: ${e.message}", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active download progress and speed"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildInitialNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("zOpoiii Downloader")
            .setContentText("Download engine active")
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "zopoiii_downloads_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.zopoiii.downloader.action.START"
        const val ACTION_STOP = "com.zopoiii.downloader.action.STOP"
        const val ACTION_PAUSE = "com.zopoiii.downloader.action.PAUSE"
        const val ACTION_RESUME = "com.zopoiii.downloader.action.RESUME"
        const val ACTION_CANCEL = "com.zopoiii.downloader.action.CANCEL"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        fun startService(context: Context) {
            try {
                val intent = Intent(context, DownloadForegroundService::class.java).apply {
                    action = ACTION_START
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e("DownloadService", "Error starting foreground service: ${e.message}")
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, DownloadForegroundService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (e: Exception) {
                Log.w("DownloadService", "Error stopping service: ${e.message}")
            }
        }

        fun updateNotification(context: Context, download: DownloadEntity, speed: SpeedInfo) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingOpen = PendingIntent.getActivity(
                context,
                0,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val pauseIntent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_PAUSE
                putExtra(EXTRA_DOWNLOAD_ID, download.id)
            }
            val pendingPause = PendingIntent.getService(
                context,
                (download.id * 10 + 1).toInt(),
                pauseIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val cancelIntent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_CANCEL
                putExtra(EXTRA_DOWNLOAD_ID, download.id)
            }
            val pendingCancel = PendingIntent.getService(
                context,
                (download.id * 10 + 2).toInt(),
                cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val percent = download.progressPercent.toInt()
            val downloadedStr = SpeedInfo.formatBytes(download.downloadedBytes)
            val totalStr = SpeedInfo.formatBytes(download.totalBytes)
            val speedStr = speed.formattedCurrentSpeed

            val subText = "$downloadedStr / $totalStr • $speedStr"

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(download.filename)
                .setContentText("$subText • $percent%")
                .setContentIntent(pendingOpen)
                .setProgress(100, percent, download.totalBytes <= 0)
                .setOngoing(download.status == DownloadStatus.DOWNLOADING)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(
                    android.R.drawable.ic_media_pause,
                    "Pause",
                    pendingPause
                )
                .addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "Cancel",
                    pendingCancel
                )

            manager.notify(NOTIFICATION_ID, builder.build())
        }
    }
}
