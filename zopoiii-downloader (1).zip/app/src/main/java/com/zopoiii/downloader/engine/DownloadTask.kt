package com.zopoiii.downloader.engine

import android.util.Log
import com.zopoiii.downloader.data.local.DownloadDao
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.data.local.SegmentDao
import com.zopoiii.downloader.data.local.SegmentEntity
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.SegmentStatus
import com.zopoiii.downloader.model.SpeedInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class DownloadTask(
    val downloadId: Long,
    private val initialEntity: DownloadEntity,
    private val downloadDao: DownloadDao,
    private val segmentDao: SegmentDao,
    private val client: OkHttpClient,
    private val rateLimiter: RateLimiter,
    private val onCompleted: (Long) -> Unit,
    private val onFailed: (Long, String) -> Unit,
    private val onProgressNotification: (DownloadEntity, SpeedInfo) -> Unit
) {
    private val TAG = "DownloadTask-$downloadId"

    private val isPaused = AtomicBoolean(false)
    private val isCancelled = AtomicBoolean(false)
    private val activeCalls = ConcurrentHashMap<Long, Call>()

    private val _speedInfo = MutableStateFlow(SpeedInfo())
    val speedInfo: StateFlow<SpeedInfo> = _speedInfo.asStateFlow()

    private val totalDownloaded = AtomicLong(initialEntity.downloadedBytes)
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        isPaused.set(false)
        isCancelled.set(false)

        job = scope.launch(Dispatchers.IO) {
            executeDownload()
        }
    }

    fun pause() {
        if (isPaused.compareAndSet(false, true)) {
            Log.d(TAG, "Pausing download $downloadId")
            cancelActiveCalls()
            job?.cancel()
        }
    }

    fun cancel() {
        if (isCancelled.compareAndSet(false, true)) {
            Log.d(TAG, "Cancelling download $downloadId")
            cancelActiveCalls()
            job?.cancel()
        }
    }

    private fun cancelActiveCalls() {
        activeCalls.values.forEach { call ->
            try {
                if (!call.isCanceled()) call.cancel()
            } catch (_: Exception) {}
        }
        activeCalls.clear()
    }

    private suspend fun executeDownload() {
        var entity = downloadDao.getDownloadById(downloadId) ?: initialEntity
        downloadDao.updateStatus(downloadId, DownloadStatus.DOWNLOADING)

        val destinationFile = File(entity.destinationPath)
        val targetDir = destinationFile.parentFile ?: File("/")
        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }

        // Check storage before resuming/starting
        val remainingRequired = if (entity.totalBytes > 0) {
            (entity.totalBytes - entity.downloadedBytes).coerceAtLeast(0L)
        } else {
            0L
        }

        if (!StorageUtils.hasEnoughStorage(targetDir, remainingRequired)) {
            val errorMsg = "Not enough storage."
            downloadDao.updateStatus(downloadId, DownloadStatus.FAILED, errorMsg)
            onFailed(downloadId, errorMsg)
            return
        }

        val partFile = FilenameUtils.getPartFile(destinationFile)

        // Load segments from database or initialize them
        var segments = segmentDao.getSegmentsForDownload(downloadId)
        if (segments.isEmpty()) {
            val segmentRanges = SmartConnectionManager.calculateSegments(
                totalBytes = entity.totalBytes,
                connectionCount = entity.connectionCount
            )

            segments = segmentRanges.mapIndexed { index, (start, end) ->
                SegmentEntity(
                    downloadId = downloadId,
                    segmentIndex = index,
                    startByte = start,
                    endByte = end,
                    downloadedBytes = 0L,
                    status = SegmentStatus.PENDING
                )
            }
            segmentDao.insertSegments(segments)
            segments = segmentDao.getSegmentsForDownload(downloadId)
        }

        // Initialize .part file size if file size is known
        if (!partFile.exists() || partFile.length() < entity.totalBytes) {
            try {
                RandomAccessFile(partFile, "rw").use { raf ->
                    if (entity.totalBytes > 0) {
                        raf.setLength(entity.totalBytes)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not pre-allocate file length: ${e.message}")
            }
        }

        val speedCalc = SpeedCalculator(
            totalBytes = entity.totalBytes,
            initialDownloadedBytes = entity.downloadedBytes
        )

        // Launch periodic UI/speed update sampler
        val samplerJob = CoroutineScope(Dispatchers.Default).launch {
            var dbSaveTick = 0
            while (isActive && !isPaused.get() && !isCancelled.get()) {
                delay(500)
                val speed = speedCalc.sample()
                _speedInfo.value = speed

                dbSaveTick++
                if (dbSaveTick % 2 == 0) { // Every 1 second
                    val currentDownloaded = totalDownloaded.get()
                    downloadDao.updateProgress(downloadId, currentDownloaded)
                    val updatedEntity = entity.copy(downloadedBytes = currentDownloaded)
                    onProgressNotification(updatedEntity, speed)
                }
            }
        }

        try {
            // Run segments in parallel
            val segmentJobs = segments.map { segment ->
                CoroutineScope(Dispatchers.IO).async {
                    downloadSegment(segment, entity, partFile, speedCalc)
                }
            }

            val results = segmentJobs.awaitAll()
            samplerJob.cancel()

            if (isPaused.get()) {
                downloadDao.updateProgress(downloadId, totalDownloaded.get())
                downloadDao.updateStatus(downloadId, DownloadStatus.PAUSED)
                return
            }

            if (isCancelled.get()) {
                downloadDao.updateProgress(downloadId, totalDownloaded.get())
                downloadDao.updateStatus(downloadId, DownloadStatus.CANCELLED)
                return
            }

            val allSucceeded = results.all { it }
            if (allSucceeded) {
                // Finalize download
                val finalDownloaded = totalDownloaded.get()
                downloadDao.updateProgress(downloadId, finalDownloaded)

                // Atomic rename .part to final
                val renameSuccess = FilenameUtils.completePartFile(partFile, destinationFile)
                if (renameSuccess) {
                    Log.d(TAG, "Download completed successfully and renamed to ${destinationFile.name}")
                    downloadDao.updateStatus(downloadId, DownloadStatus.COMPLETED)
                    onCompleted(downloadId)
                } else {
                    val msg = "Failed to rename .part file to ${destinationFile.name}"
                    downloadDao.updateStatus(downloadId, DownloadStatus.FAILED, msg)
                    onFailed(downloadId, msg)
                }
            } else {
                val errorMsg = "One or more segments failed to download"
                downloadDao.updateStatus(downloadId, DownloadStatus.FAILED, errorMsg)
                onFailed(downloadId, errorMsg)
            }
        } catch (e: CancellationException) {
            samplerJob.cancel()
            downloadDao.updateProgress(downloadId, totalDownloaded.get())
            if (isPaused.get()) {
                downloadDao.updateStatus(downloadId, DownloadStatus.PAUSED)
            } else if (isCancelled.get()) {
                downloadDao.updateStatus(downloadId, DownloadStatus.CANCELLED)
            }
        } catch (e: Exception) {
            samplerJob.cancel()
            Log.e(TAG, "Error executing download", e)
            val errorMsg = e.message ?: "Download interrupted"
            downloadDao.updateStatus(downloadId, DownloadStatus.FAILED, errorMsg)
            onFailed(downloadId, errorMsg)
        }
    }

    private suspend fun downloadSegment(
        segment: SegmentEntity,
        entity: DownloadEntity,
        partFile: File,
        speedCalc: SpeedCalculator
    ): Boolean {
        if (segment.status == SegmentStatus.COMPLETED) {
            return true
        }

        var currentDownloaded = segment.downloadedBytes
        val segmentTotalBytes = segment.totalSegmentBytes

        if (currentDownloaded >= segmentTotalBytes && segmentTotalBytes > 0) {
            segmentDao.updateSegmentProgress(segment.segmentId, segmentTotalBytes, SegmentStatus.COMPLETED)
            return true
        }

        // Retry with exponential backoff: 5s, 10s, 30s, 60s
        val backoffDelays = listOf(0L, 5000L, 10000L, 30000L, 60000L)
        var attempt = 0

        while (attempt < backoffDelays.size && !isPaused.get() && !isCancelled.get()) {
            val delayMs = backoffDelays[attempt]
            if (delayMs > 0) {
                Log.d(TAG, "Segment ${segment.segmentIndex} retrying in ${delayMs / 1000}s (attempt $attempt)...")
                delay(delayMs)
            }
            attempt++

            if (isPaused.get() || isCancelled.get()) return false

            segmentDao.updateSegmentProgress(segment.segmentId, currentDownloaded, SegmentStatus.DOWNLOADING)

            var raf: RandomAccessFile? = null
            try {
                raf = RandomAccessFile(partFile, "rw")
                val startPos = segment.startByte + currentDownloaded
                raf.seek(startPos)

                val requestBuilder = Request.Builder()
                    .url(entity.url)
                    .header("User-Agent", "zOpoiii-Downloader/1.0 (Android)")

                if (entity.acceptRanges && entity.totalBytes > 0) {
                    val rangeEnd = segment.endByte
                    requestBuilder.header("Range", "bytes=$startPos-$rangeEnd")
                } else if (currentDownloaded > 0) {
                    requestBuilder.header("Range", "bytes=$startPos-")
                }

                val request = requestBuilder.build()
                val call = client.newCall(request)
                activeCalls[segment.segmentId] = call

                val response = call.execute()
                if (!response.isSuccessful && response.code != 206) {
                    response.close()
                    activeCalls.remove(segment.segmentId)
                    throw IOException("HTTP ${response.code}")
                }

                val responseBody = response.body ?: throw IOException("Empty response body")
                val inputStream = responseBody.byteStream()
                val buffer = ByteArray(64 * 1024) // 64KB streaming buffer

                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    if (isPaused.get() || isCancelled.get()) {
                        response.close()
                        activeCalls.remove(segment.segmentId)
                        return false
                    }

                    // Enforce speed rate limit
                    rateLimiter.acquire(bytesRead)

                    raf.write(buffer, 0, bytesRead)
                    currentDownloaded += bytesRead
                    totalDownloaded.addAndGet(bytesRead.toLong())
                    speedCalc.addBytes(bytesRead.toLong())

                    // Check if segment is bounded and reached end
                    if (entity.totalBytes > 0 && currentDownloaded >= segmentTotalBytes) {
                        break
                    }
                }

                raf.fd.sync()
                response.close()
                activeCalls.remove(segment.segmentId)

                segmentDao.updateSegmentProgress(segment.segmentId, currentDownloaded, SegmentStatus.COMPLETED)
                return true

            } catch (e: Exception) {
                activeCalls.remove(segment.segmentId)
                try { raf?.fd?.sync() } catch (_: Exception) {}
                try { raf?.close() } catch (_: Exception) {}

                if (isPaused.get() || isCancelled.get()) {
                    segmentDao.updateSegmentProgress(segment.segmentId, currentDownloaded, SegmentStatus.PENDING)
                    return false
                }

                Log.w(TAG, "Segment ${segment.segmentIndex} attempt $attempt failed: ${e.message}")
                segmentDao.updateSegmentProgress(segment.segmentId, currentDownloaded, SegmentStatus.FAILED)
            } finally {
                try { raf?.close() } catch (_: Exception) {}
            }
        }

        return false
    }
}
