package com.zopoiii.downloader.engine

import java.io.File
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.regex.Pattern

object FilenameUtils {

    private val FILENAME_STAR_PATTERN = Pattern.compile(
        """filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)""",
        Pattern.CASE_INSENSITIVE
    )

    private val FILENAME_QUOTED_PATTERN = Pattern.compile(
        """filename\s*=\s*"([^"]+)"""",
        Pattern.CASE_INSENSITIVE
    )

    private val FILENAME_UNQUOTED_PATTERN = Pattern.compile(
        """filename\s*=\s*([^;\s]+)""",
        Pattern.CASE_INSENSITIVE
    )

    /**
     * Extracts filename using priority:
     * 1. Content-Disposition filename
     * 2. Content-Disposition filename* (RFC 5987)
     * 3. URL path
     * 4. Fallback default
     */
    fun extractFilename(
        contentDisposition: String?,
        url: String,
        fallback: String = "download_file.bin"
    ): String {
        // Priority 1: standard filename="..." or filename=...
        if (!contentDisposition.isNullOrBlank()) {
            val quotedMatcher = FILENAME_QUOTED_PATTERN.matcher(contentDisposition)
            if (quotedMatcher.find()) {
                val candidate = quotedMatcher.group(1)?.trim()
                if (!candidate.isNullOrBlank()) {
                    val sanitized = sanitizeFilename(candidate)
                    if (sanitized.isNotBlank()) return sanitized
                }
            }

            // Priority 2: filename* (RFC 5987 / RFC 6266)
            val starMatcher = FILENAME_STAR_PATTERN.matcher(contentDisposition)
            if (starMatcher.find()) {
                val rawEncoded = starMatcher.group(1)?.trim()
                if (!rawEncoded.isNullOrBlank()) {
                    try {
                        val decoded = URLDecoder.decode(rawEncoded, StandardCharsets.UTF_8.name())
                        val sanitized = sanitizeFilename(decoded)
                        if (sanitized.isNotBlank()) return sanitized
                    } catch (_: Exception) {
                    }
                }
            }

            val unquotedMatcher = FILENAME_UNQUOTED_PATTERN.matcher(contentDisposition)
            if (unquotedMatcher.find()) {
                val candidate = unquotedMatcher.group(1)?.trim()
                if (!candidate.isNullOrBlank()) {
                    val sanitized = sanitizeFilename(candidate)
                    if (sanitized.isNotBlank()) return sanitized
                }
            }
        }

        // Priority 3: extract from URL path
        val urlFilename = extractFilenameFromUrl(url)
        if (urlFilename.isNotBlank()) {
            return urlFilename
        }

        // Priority 4: fallback
        return fallback
    }

    fun extractFilenameFromUrl(url: String): String {
        return try {
            val cleanUrl = if (url.contains("?")) url.substring(0, url.indexOf("?")) else url
            val withoutHash = if (cleanUrl.contains("#")) cleanUrl.substring(0, cleanUrl.indexOf("#")) else cleanUrl
            val lastSlash = withoutHash.lastIndexOf('/')
            if (lastSlash != -1 && lastSlash < withoutHash.length - 1) {
                val rawName = withoutHash.substring(lastSlash + 1)
                val decoded = URLDecoder.decode(rawName, StandardCharsets.UTF_8.name())
                sanitizeFilename(decoded)
            } else {
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    fun sanitizeFilename(filename: String): String {
        // Replace illegal filesystem characters: / \ : * ? " < > |
        var cleaned = filename.replace("[/\\\\:*?\"<>|]".toRegex(), "_").trim()
        // Prevent leading dots or path traversal
        while (cleaned.startsWith(".")) {
            cleaned = cleaned.removePrefix(".").trim()
        }
        return if (cleaned.isBlank()) "download_file.bin" else cleaned
    }

    /**
     * Resolves duplicate filenames: file.zip -> file (1).zip -> file (2).zip
     */
    fun resolveDuplicateFilename(targetDir: File, originalFilename: String): String {
        val destFile = File(targetDir, originalFilename)
        if (!destFile.exists()) {
            return originalFilename
        }

        val dotIndex = originalFilename.lastIndexOf('.')
        val baseName = if (dotIndex > 0) originalFilename.substring(0, dotIndex) else originalFilename
        val extension = if (dotIndex > 0) originalFilename.substring(dotIndex) else ""

        var counter = 1
        while (true) {
            val newName = "$baseName ($counter)$extension"
            val candidate = File(targetDir, newName)
            if (!candidate.exists()) {
                return newName
            }
            counter++
        }
    }

    fun getPartFile(destinationFile: File): File {
        return File(destinationFile.parentFile, "${destinationFile.name}.part")
    }

    /**
     * Atomic or safe rename of .part file to final file
     */
    fun completePartFile(partFile: File, finalFile: File): Boolean {
        if (!partFile.exists()) return false
        if (finalFile.exists()) {
            finalFile.delete()
        }
        return partFile.renameTo(finalFile)
    }
}
