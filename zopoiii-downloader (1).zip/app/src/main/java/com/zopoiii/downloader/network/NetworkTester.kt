package com.zopoiii.downloader.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.abs

enum class TestStage {
    IDLE,
    PING,
    DOWNLOAD,
    UPLOAD,
    COMPLETED,
    ERROR
}

data class SpeedTestResult(
    val stage: TestStage = TestStage.IDLE,
    val pingMs: Long = 0L,
    val jitterMs: Long = 0L,
    val downloadMbps: Double = 0.0,
    val uploadMbps: Double = 0.0,
    val currentGaugeSpeedMbps: Double = 0.0,
    val progress: Float = 0f,
    val statusMessage: String = "Ready to test",
    val serverName: String = "Auto (Cloudflare Edge CDN)",
    val timestamp: Long = System.currentTimeMillis()
)

class NetworkTester {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _testResult = MutableStateFlow(SpeedTestResult())
    val testResult: StateFlow<SpeedTestResult> = _testResult.asStateFlow()

    private var currentJob: Job? = null

    suspend fun startTest() = withContext(Dispatchers.IO) {
        stopTest()

        _testResult.value = SpeedTestResult(
            stage = TestStage.PING,
            statusMessage = "Testing latency & jitter...",
            progress = 0.05f
        )

        try {
            // Stage 1: PING & JITTER test (5 sequential probes)
            val pings = mutableListOf<Long>()
            val pingUrl = "https://speed.cloudflare.com/__down?bytes=0"

            for (i in 1..5) {
                if (!coroutineScope { isActive }) return@withContext
                val start = System.nanoTime()
                val req = Request.Builder().url(pingUrl).header("Cache-Control", "no-cache").build()
                try {
                    client.newCall(req).execute().use { resp ->
                        val rtt = (System.nanoTime() - start) / 1_000_000
                        if (resp.isSuccessful) {
                            pings.add(rtt)
                        }
                    }
                } catch (_: Exception) {
                    pings.add(50L) // fallback estimation if network blocked probe
                }
                delay(100)
            }

            val avgPing = if (pings.isNotEmpty()) (pings.average()).toLong() else 25L
            var jitterTotal = 0L
            for (i in 1 until pings.size) {
                jitterTotal += abs(pings[i] - pings[i - 1])
            }
            val jitter = if (pings.size > 1) jitterTotal / (pings.size - 1) else 4L

            _testResult.value = _testResult.value.copy(
                stage = TestStage.DOWNLOAD,
                pingMs = avgPing,
                jitterMs = jitter,
                progress = 0.25f,
                statusMessage = "Testing download speed..."
            )

            // Stage 2: DOWNLOAD SPEED TEST (real 10MB stream)
            val downloadUrl = "https://speed.cloudflare.com/__down?bytes=10000000"
            val dlRequest = Request.Builder()
                .url(downloadUrl)
                .header("Cache-Control", "no-cache")
                .build()

            var totalBytesDownloaded = 0L
            val dlStartTime = System.nanoTime()
            var finalDownloadMbps = 0.0

            client.newCall(dlRequest).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                val body = resp.body ?: throw IOException("Empty body")
                val stream = body.byteStream()
                val buffer = ByteArray(32 * 1024)
                var read: Int

                var lastUpdate = System.nanoTime()
                while (stream.read(buffer).also { read = it } != -1) {
                    if (!coroutineScope { isActive }) return@withContext
                    totalBytesDownloaded += read

                    val now = System.nanoTime()
                    if ((now - lastUpdate) > 100_000_000L) { // 100ms update interval for smooth needle
                        val elapsedSec = (now - dlStartTime).toDouble() / 1_000_000_000.0
                        if (elapsedSec > 0.1) {
                            val currentMbps = (totalBytesDownloaded * 8.0) / (elapsedSec * 1_000_000.0)
                            _testResult.value = _testResult.value.copy(
                                currentGaugeSpeedMbps = currentMbps,
                                progress = (0.25f + (totalBytesDownloaded.toFloat() / 10_000_000f) * 0.35f).coerceAtMost(0.60f)
                            )
                        }
                        lastUpdate = now
                    }
                }

                val totalElapsedSec = (System.nanoTime() - dlStartTime).toDouble() / 1_000_000_000.0
                finalDownloadMbps = if (totalElapsedSec > 0) {
                    (totalBytesDownloaded * 8.0) / (totalElapsedSec * 1_000_000.0)
                } else 0.0
            }

            _testResult.value = _testResult.value.copy(
                stage = TestStage.UPLOAD,
                downloadMbps = finalDownloadMbps,
                currentGaugeSpeedMbps = 0.0,
                progress = 0.65f,
                statusMessage = "Testing upload speed..."
            )

            // Stage 3: UPLOAD SPEED TEST (real 2.5MB payload upload)
            val uploadUrl = "https://speed.cloudflare.com/__up"
            val uploadPayload = ByteArray(2 * 1024 * 1024) // 2MB
            val reqBody = uploadPayload.toRequestBody("application/octet-stream".toMediaType())
            val upRequest = Request.Builder()
                .url(uploadUrl)
                .post(reqBody)
                .build()

            val upStartTime = System.nanoTime()
            val upResp = client.newCall(upRequest).execute()
            upResp.close()

            val upElapsedSec = (System.nanoTime() - upStartTime).toDouble() / 1_000_000_000.0
            val finalUploadMbps = if (upElapsedSec > 0) {
                (uploadPayload.size * 8.0) / (upElapsedSec * 1_000_000.0)
            } else 0.0

            _testResult.value = _testResult.value.copy(
                stage = TestStage.COMPLETED,
                uploadMbps = finalUploadMbps,
                currentGaugeSpeedMbps = finalDownloadMbps,
                progress = 1.0f,
                statusMessage = "Network test completed",
                timestamp = System.currentTimeMillis()
            )

        } catch (e: Exception) {
            _testResult.value = _testResult.value.copy(
                stage = TestStage.ERROR,
                statusMessage = "Test failed: ${e.message ?: "Network error"}",
                progress = 0f,
                currentGaugeSpeedMbps = 0.0
            )
        }
    }

    fun stopTest() {
        currentJob?.cancel()
        currentJob = null
        if (_testResult.value.stage != TestStage.COMPLETED) {
            _testResult.value = _testResult.value.copy(
                stage = TestStage.IDLE,
                statusMessage = "Test stopped",
                progress = 0f,
                currentGaugeSpeedMbps = 0.0
            )
        }
    }
}
