package com.zopoiii.downloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zopoiii.downloader.data.local.AppDatabase
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.data.local.SegmentEntity
import com.zopoiii.downloader.data.preferences.AppSettings
import com.zopoiii.downloader.data.preferences.SettingsDataStore
import com.zopoiii.downloader.engine.DownloadManager
import com.zopoiii.downloader.engine.StorageUtils
import com.zopoiii.downloader.engine.UrlMetadataResolver
import com.zopoiii.downloader.model.ConnectionMode
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.FileMetadata
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.network.NetworkMonitor
import com.zopoiii.downloader.network.NetworkState
import com.zopoiii.downloader.network.NetworkTester
import com.zopoiii.downloader.network.SpeedTestResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UrlProbeState(
    val isLoading: Boolean = false,
    val metadata: FileMetadata? = null,
    val isStorageSufficient: Boolean = true,
    val availableStorageBytes: Long = 0L,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val downloadDao = db.downloadDao()
    private val segmentDao = db.segmentDao()
    private val downloadManager = DownloadManager.getInstance(application)
    private val settingsDataStore = SettingsDataStore(application)
    private val networkMonitor = NetworkMonitor(application)
    private val networkTester = NetworkTester()

    val allDownloads: StateFlow<List<DownloadEntity>> = downloadDao.getAllDownloads()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speeds: StateFlow<Map<Long, SpeedInfo>> = downloadManager.speeds

    val appSettings: StateFlow<AppSettings> = settingsDataStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val networkState: StateFlow<NetworkState> = networkMonitor.networkState

    val speedTestResult: StateFlow<SpeedTestResult> = networkTester.testResult

    private val _urlProbeState = MutableStateFlow(UrlProbeState())
    val urlProbeState: StateFlow<UrlProbeState> = _urlProbeState.asStateFlow()

    init {
        viewModelScope.launch {
            downloadManager.recoverAfterRestart()
        }
    }

    fun probeUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed.isBlank()) {
            _urlProbeState.value = UrlProbeState(errorMessage = "Please enter a valid URL")
            return
        }

        viewModelScope.launch {
            _urlProbeState.value = UrlProbeState(isLoading = true)
            val result = UrlMetadataResolver.resolve(trimmed)
            result.fold(
                onSuccess = { metadata ->
                    val defaultDir = StorageUtils.getDefaultDownloadDirectory(getApplication())
                    val available = StorageUtils.getAvailableStorageBytes(defaultDir)
                    val sufficient = StorageUtils.hasEnoughStorage(defaultDir, metadata.totalBytes)
                    _urlProbeState.value = UrlProbeState(
                        isLoading = false,
                        metadata = metadata,
                        isStorageSufficient = sufficient,
                        availableStorageBytes = available
                    )
                },
                onFailure = { error ->
                    _urlProbeState.value = UrlProbeState(
                        isLoading = false,
                        errorMessage = error.message ?: "Failed to resolve download URL"
                    )
                }
            )
        }
    }

    fun clearProbe() {
        _urlProbeState.value = UrlProbeState()
    }

    fun startDownloadFromMetadata(metadata: FileMetadata, customName: String? = null) {
        viewModelScope.launch {
            downloadManager.enqueueDownload(metadata, customName)
            clearProbe()
        }
    }

    fun pauseDownload(id: Long) {
        downloadManager.pauseDownload(id)
    }

    fun resumeDownload(id: Long) {
        downloadManager.startOrResume(id)
    }

    fun cancelDownload(id: Long) {
        downloadManager.cancelDownload(id)
    }

    fun retryDownload(id: Long) {
        downloadManager.retryDownload(id)
    }

    fun deleteDownload(id: Long, deleteFileFromStorage: Boolean) {
        viewModelScope.launch {
            downloadManager.deleteDownload(id, deleteFileFromStorage)
        }
    }

    fun getSegmentsForDownload(downloadId: Long): Flow<List<SegmentEntity>> {
        return segmentDao.getSegmentsForDownloadFlow(downloadId)
    }

    fun getDownloadById(downloadId: Long): Flow<DownloadEntity?> {
        return downloadDao.getDownloadByIdFlow(downloadId)
    }

    // Network Test controls
    fun startNetworkTest() {
        viewModelScope.launch {
            networkTester.startTest()
        }
    }

    fun stopNetworkTest() {
        networkTester.stopTest()
    }

    // Settings controls
    fun updateConnectionMode(mode: ConnectionMode) {
        viewModelScope.launch { settingsDataStore.updateConnectionMode(mode) }
    }

    fun updateMaxConnections(count: Int) {
        viewModelScope.launch { settingsDataStore.updateMaxConnections(count) }
    }

    fun updateSpeedLimit(bytesPerSec: Long) {
        viewModelScope.launch { settingsDataStore.updateSpeedLimit(bytesPerSec) }
    }

    fun updateRetryAuto(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateRetryAuto(enabled) }
    }

    fun updateAutoResume(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateAutoResume(enabled) }
    }

    fun updateBackgroundDownload(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateBackgroundDownload(enabled) }
    }

    fun updateDownloadOnlyWifi(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateDownloadOnlyWifi(enabled) }
    }

    fun updatePauseWhenMobile(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updatePauseWhenMobile(enabled) }
    }

    fun updateContinueLowBattery(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateContinueLowBattery(enabled) }
    }

    fun updateLowBatteryThreshold(threshold: Int) {
        viewModelScope.launch { settingsDataStore.updateLowBatteryThreshold(threshold) }
    }

    fun updateMaxSimultaneousDownloads(max: Int) {
        viewModelScope.launch { settingsDataStore.updateMaxSimultaneousDownloads(max) }
    }

    suspend fun verifyChecksum(
        downloadId: Long,
        expectedHash: String,
        algorithm: String
    ): Result<Boolean> {
        return downloadManager.verifyChecksum(downloadId, expectedHash, algorithm)
    }
}
